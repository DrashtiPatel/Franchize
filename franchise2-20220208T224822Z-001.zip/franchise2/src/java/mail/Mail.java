package mail;

import javax.mail.*;

import javax.mail.internet.*;

import java.util.*;

import javax.activation.*;
import javax.swing.JOptionPane;

public class Mail {

    private String to;
    private String from;
    private String message;
    private String subject;
    private String smtpServ;
    private String filename;

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getSmtpServ() {
        return smtpServ;
    }

    public void setSmtpServ(String smtpServ) {
        this.smtpServ = smtpServ;
    }

    public int sendMail() {

        try {
           
            Properties props = System.getProperties();
            props.put("mail.transport.protocol", "smtp");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", smtpServ);
            props.put("mail.smtp.auth", "true");

            
            SMTPAuthenticator auth = new SMTPAuthenticator();
            Session session = Session.getInstance(props, auth);
            // -- Create a new message --

            Message msg = new MimeMessage(session);
            // -- Set the FROM and TO fields --

            
            msg.setFrom(new InternetAddress(from));

            msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to, false));
            // -- We could include CC recipients too --

            // if (cc != null)

            // msg.setRecipients(Message.RecipientType.CC
            // ,InternetAddress.parse(cc, false));
            // -- Set the subject and body text --
            
            msg.setSubject(subject);
            msg.setText(message);
            msg.setHeader("MyMail", "Java Mail Test");
            msg.setSentDate(new Date());

            /* MimeBodyPart mbp2 = new MimeBodyPart();

            // attach the file to the message
            FileDataSource fds = new FileDataSource(getFilename());
            mbp2.setDataHandler(new DataHandler(fds));
            mbp2.setFileName(fds.getName());*/

            // create the Multipart and add its parts to it


            // Multipart mp = new MimeMultipart();
            //   mp.addBodyPart(mbp2);

            // add the Multipart to the message
            // JOptionPane.showMessageDialog(null, getFilename());

            //   msg.setContent(mp);
            //JOptionPane.showMessageDialog(null, msg);
            // -- Send the message --

            JOptionPane.showMessageDialog(null, "Test1");
            Transport.send(msg);
            JOptionPane.showMessageDialog(null, "Test2");
            System.out.println("Message sent to" + to + " OK.");
            JOptionPane.showMessageDialog(null, "Test3");

            return 0;
        } catch (Exception ex) {


            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, ex.getMessage());
            System.out.println("Exception " + ex);

            return -1;

        }
    }

     public int sendactivationmail(String id,String key) {

        try {
        this.to=id;
        this.message=key;
        this.smtpServ="smtp.gmail.com";
        this.from="franchisesolutions2013@gmail.com";
        this.subject="Confirmation Mail";
            Properties props = System.getProperties();
            props.put("mail.transport.protocol", "smtp");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", smtpServ);
            props.put("mail.smtp.auth", "true");


            SMTPAuthenticator auth = new SMTPAuthenticator();
            Session session = Session.getInstance(props, auth);
            // -- Create a new message --

            Message msg = new MimeMessage(session);
            // -- Set the FROM and TO fields --


            msg.setFrom(new InternetAddress(from));

            msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to, false));
            msg.setSubject(subject);
            msg.setText(message);
            msg.setHeader("MyMail", "Java Mail Test");
            msg.setSentDate(new Date());
            Transport.send(msg);
            System.out.println("Message sent to" + to + " OK.");


            return 0;
        } catch (Exception ex) {


            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, ex.getMessage());
            System.out.println("Exception " + ex);

            return -1;

        }
    }

    /**
     * @return the filename
     */
    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    private class SMTPAuthenticator extends javax.mail.Authenticator {

        @Override
        public PasswordAuthentication getPasswordAuthentication() {

            String username = "franchisesolutions2013@gmail.com";

            String password = "shefalitwinkle";


            return new PasswordAuthentication(username, password);

        }
    }
}
