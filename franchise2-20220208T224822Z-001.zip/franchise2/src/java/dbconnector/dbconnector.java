/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package dbconnector;

import com.mysql.jdbc.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class dbconnector {
    public Connection conn;
    public PreparedStatement p;
    public Statement s;
    public ResultSet r;


    public void connect()
    {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(dbconnector.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
          conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/franchise2", "root", "");
        } catch (SQLException ex) {
            Logger.getLogger(dbconnector.class.getName()).log(Level.SEVERE, null, ex);
        }

    }


    public void executepreparedstatement(String query) throws SQLException
    {

            p = conn.prepareStatement(query);



    }
    public void executestatement(String query) throws SQLException
    {

           s= (Statement) conn.createStatement();

            r = s.executeQuery(query);

    }
}




