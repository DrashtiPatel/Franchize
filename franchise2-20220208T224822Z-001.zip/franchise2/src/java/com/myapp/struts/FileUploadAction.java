package com.myapp.struts;

import dbconnector.dbconnector;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.FormFile;

public class FileUploadAction extends org.apache.struts.action.Action {

    private static final String SUCCESS = "success";

    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        PrintWriter out = response.getWriter();
        String usertype = "company";

        String email = request.getParameter("email");
        String confirm_email = request.getParameter("confirm_email");
        String password = request.getParameter("password");
        String confirm_pass = request.getParameter("confirm_pass");
        String sec_que = request.getParameter("sec_que");
        String sec_ans = request.getParameter("sec_ans");

        String query1 = "insert into login values(?,?,?,?,?)";

        try {
            if (email.equals(confirm_email) && password.equals(confirm_pass)) {

                FileUploadForm fileUploadForm = (FileUploadForm) form;

                FormFile file = fileUploadForm.getFile();
                HttpSession ses = request.getSession(true);
                //Get the servers upload directory real path name
                String filePath = getServlet().getServletContext().getRealPath("/") + "upload/";

                //create the upload folder if not exists
                File folder = new File(filePath);
                if (!folder.exists()) {
                    folder.mkdir();
                }

                String fileName = file.getFileName();

                if (!("").equals(fileName)) {

                    System.out.println("Server path:" + filePath);
                    //JOptionPane.showMessageDialog(null,filePath);
                    File newFile = new File(filePath, fileName);

                    if (!newFile.exists()) {
                        FileOutputStream fos = new FileOutputStream(newFile);
                        fos.write(file.getFileData());
                        fos.flush();
                        fos.close();
                    }

                    request.setAttribute("uploadedFilePath", newFile.getAbsoluteFile());
                    request.setAttribute("uploadedFileName", newFile.getName());
                    String image = (String) request.getAttribute("uploadedFileName");
                    try {
                        dbconnector db = new dbconnector();
                        db.connect();
                        db.executepreparedstatement(query1);
                        db.p.setString(1, email);
                        db.p.setString(2, password);
                        db.p.setString(3, usertype);
                        db.p.setString(4, sec_que);
                        db.p.setString(5, sec_ans);

                        db.p.executeUpdate();

                        
                        JOptionPane.showMessageDialog(null, "test2");
                        String query2 = "insert into fsor_req values(?,?,?,?)";
                        String area = request.getParameter("area");
                        String budget = request.getParameter("budget");
                        String expansion = "";

                        String chkboxs[] = request.getParameterValues("cb");
                        for (int i = 0; i < chkboxs.length; i++) {

                            expansion += chkboxs[i] + " ";
                        }
                        db.executepreparedstatement(query2);
                        db.p.setString(1, email);
                        db.p.setString(2, area);
                        db.p.setString(3, budget);
                        db.p.setString(4, expansion);
                        db.p.executeUpdate();

                        JOptionPane.showMessageDialog(null, "test4");
                        String query3 = " insert into fsor_details values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";



                        String c_name = request.getParameter("c_name");
                        String c_address = request.getParameter("c_address");
                        String state = request.getParameter("state");
                        String city = request.getParameter("city");
                        String country = request.getParameter("country");
                        String pincode = request.getParameter("pincode");
                        String mob = request.getParameter("mob");
                        String phone = request.getParameter("phone");
                        String fax = request.getParameter("fax");
                        String website = request.getParameter("website");
                        String sec_email = request.getParameter("sec_email");
                        String industry = request.getParameter("industry");
                        String total_outlets = request.getParameter("total_outlets");
                        String comp_outlets = request.getParameter("comp_outlets");
                        String fsee_outlets = request.getParameter("fsee_outlets");
                        String ceo_name = request.getParameter("ceo_name");

                        db.executepreparedstatement(query3);
                        db.p.setString(1, email);
                        db.p.setString(2, c_name);
                        db.p.setString(3, c_address);
                        db.p.setString(4, country);
                        db.p.setString(5, state);
                        db.p.setString(6, city);
                        db.p.setString(7, pincode);
                        db.p.setString(8, mob);
                        db.p.setString(9, phone);
                        db.p.setString(10, fax);
                        db.p.setString(11, website);
                        db.p.setString(12, sec_email);
                        db.p.setString(13, industry);
                        db.p.setString(14, total_outlets);
                        db.p.setString(15, comp_outlets);
                        db.p.setString(16, fsee_outlets);
                        db.p.setString(17, ceo_name);
                        db.p.executeUpdate();

                        db.executepreparedstatement("insert into address_book values(?,?,?,?)");
                        db.p.setString(1, usertype);
                        db.p.setString(2, email);
                        db.p.setString(3, mob);
                        db.p.setString(4, c_name);
                        db.p.executeUpdate();


                        String t_provided = request.getParameter("t_provided");
                        String t_venue = request.getParameter("t_venue");
                        // String comp_logo = request.getParameter("comp_logo");
                        String comp_info = request.getParameter("comp_details");




                        String query4 = "insert into fsor_training(email,t_provided,t_venue,comp_logo,comp_info) values (?,?,?,?,?)";
                        db.executepreparedstatement(query4);
                        JOptionPane.showMessageDialog(null, email);
                        db.p.setString(1, email);
                        db.p.setString(2, t_provided);
                        db.p.setString(3, t_venue);
                        db.p.setString(4, fileName);
                        db.p.setString(5, comp_info);


                        db.p.executeUpdate();
                        JOptionPane.showMessageDialog(null, "done3");
                        String query = "update fsor_training set comp_logo='" + image + "' where email=" + "'" + email + "'";
                        db.executepreparedstatement(query);
                        db.p.executeUpdate();
                        JOptionPane.showMessageDialog(null, "done");

                        ses.setAttribute("email" , email);
                        ses.setAttribute("usertype", usertype);
                        response.sendRedirect("companyhome.jsp");
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, e);
                    }


                }
            }
        } finally {
            out.close();
        }
        return mapping.findForward("success");
    }
}
