/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import dbconnector.dbconnector;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

/**
 *
 * @author Dell
 */
public class changepassword_action extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            HttpSession session = request.getSession();

            String old_password = (String) request.getParameter("old_password");
            String email = (String) session.getAttribute("email");
            String new_password = (String) request.getParameter("new_password");
            String confirm_password = (String) request.getParameter("confirm_password");

            if (old_password.equals("")) {
                old_password = null;
            }

            //     JOptionPane.showMessageDialog(null, "username"+old_password);
            String query1 = "select * from login where email='" + email + "'";
            String query2 = "update login set password='" + new_password + "' where email='" + email + "'";

            dbconnector db = new dbconnector();
            db.connect();
            db.executestatement(query1);
            if (db.r.next()) {
                String db_password = db.r.getString(2);
                String usertype = db.r.getString(3);
                if (db_password.equals(old_password)) {

                    if (new_password.equals(confirm_password)) {
                        db.executepreparedstatement(query2);
                        db.p.executeUpdate();
                        JOptionPane.showMessageDialog(null, "Password updated successfully");
                        if(usertype.equals("investor")){
                            response.sendRedirect("investorhome.jsp");
                        }
                        else if(usertype.equals("company")){
                            response.sendRedirect("companyhome.jsp");
                        }
                        else if(usertype.equals("admin")){
                            response.sendRedirect("adminwelcome.jsp");
                        }
                        
                    } else {
                        JOptionPane.showMessageDialog(null, "password mismatch");
                        response.sendRedirect("changepassword.jsp");
                    }

                }



            } else {
                JOptionPane.showMessageDialog(null, "password mismatch");
            }



            /* TODO output your page here
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet changepassword_action</title>");  
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet changepassword_action at " + request.getContextPath () + "</h1>");
            out.println("</body>");
            out.println("</html>");
             */
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
