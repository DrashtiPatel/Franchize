/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import dbconnector.dbconnector;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

/**
 *
 * @author Dell
 */
public class editscheme extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();
        try {
            String scheme_id = (String) session.getAttribute("scheme_id");
           // session.removeAttribute("scheme_id");
            //JOptionPane.showMessageDialog(null, scheme_id);
            String scheme_name = request.getParameter("schemename");
            String scheme_type = request.getParameter("schemetype");
            String discount = request.getParameter("discount");
            String condition = request.getParameter("condition");

            String start_date = request.getParameter("stdate");
            String end_date = request.getParameter("enddate");

            //JOptionPane.showMessageDialog(null, start_date + "" + end_date);
            String query = "update scheme_master set s_name='" + scheme_name + "',s_type='" + scheme_type + "',s_discount='" + discount + "',s_condition='" + condition + "',s_startdate='" + start_date + "',s_enddate='" + end_date + "' where scheme_id='" + scheme_id + "'";
            dbconnector db = new dbconnector();
            db.connect();
            db.executepreparedstatement(query);
            db.p.executeUpdate();
          //  JOptionPane.showMessageDialog(null, scheme_name + scheme_type + discount + condition + end_date);
            session.setAttribute("current1", 0);
            JOptionPane.showMessageDialog(null, "Updated Succesfully");
            response.sendRedirect("adminshowscheme.jsp");
            /* TODO output your page here
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet editscheme</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet editscheme at " + request.getContextPath () + "</h1>");
            out.println("</body>");
            out.println("</html>");
             */
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
        finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
