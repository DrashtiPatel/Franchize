/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import dbconnector.dbconnector;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

/**
 *
 * @author Shefali
 */
public class inv_update extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            HttpSession session = request.getSession();
            String firstname = request.getParameter("fname");
            String surname = request.getParameter("sname");
            String address = request.getParameter("address");
            String state = request.getParameter("state");
            String city = request.getParameter("city");
            String country = request.getParameter("country");
            String pincode = request.getParameter("pincode");
            String mobileno = request.getParameter("mob");
            String phone = request.getParameter("phone");
            String fax = request.getParameter("fax");
            String occupation = request.getParameter("occupation");


            String industry = request.getParameter("industry");
            String exp = request.getParameter("exp");
            String brand = request.getParameter("brand");
            String pref1 = request.getParameter("pref1");
            String pref2 = request.getParameter("pref2");
            String pref3 = request.getParameter("pref3");


            String capacity = request.getParameter("capacity");
            String invest_time = request.getParameter("invest_time");
            String property_add = request.getParameter("property_add");
            String area = request.getParameter("area");
            String usage = request.getParameter("usage");



            String email = (String) session.getAttribute("email");
            String query1 = "update fsee_details set fname='" + firstname + "', sname='" + surname + "' , address='" + address + "' , state='" + state + "' , city='" + city + "' , country='" + country + "' , pincode='" + pincode + "' , mob='" + mobileno + "' , phone='" + phone + "' , fax='" + fax + "' , occupation='" + occupation + "' where email='" + email + "'";
            String query2 = "update fsee_exp set industry='" + industry + "', exp='" + exp + "' , brand='" + brand + "' , pref1='" + pref1 + "' , pref2='" + pref2 + "' , pref3='" + pref3 + "' where email='" + email + "'";
         //   String query3 = "update fsee_invest set capacity='" + capacity + "' , invest_time='" + invest_time + "' , property_add='" + property_add + "' , area='" + area + "' , usage='" + usage + "' where email='" + email + "'";
            JOptionPane.showMessageDialog(null, "email:" + email);
            if (email == null) {
                response.sendRedirect("index.jsp");
            } else {
                dbconnector db = new dbconnector();
                db.connect();
                db.executepreparedstatement(query1);               
                db.p.executeUpdate();
                
                db.executepreparedstatement(query2);
                db.p.executeUpdate();
                
            //    db.executepreparedstatement(query3);
             //  db.p.executeUpdate();

                JOptionPane.showMessageDialog(null, "update successful");
                response.sendRedirect("investorhome.jsp");
                
                    /* TODO output your page here
                    out.println("<html>");
                    out.println("<head>");
                    out.println("<title>Servlet inv_update</title>");
                    out.println("</head>");
                    out.println("<body>");
                    out.println("<h1>Servlet inv_update at " + request.getContextPath () + "</h1>");
                    out.println("</body>");
                    out.println("</html>");
                     */
                
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            System.out.println(e);
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
