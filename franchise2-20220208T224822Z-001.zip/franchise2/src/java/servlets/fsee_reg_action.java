/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import dbconnector.dbconnector;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

/**
 *
 * @author Shreeji
 */
public class fsee_reg_action extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession();

        String usertype = "investor" ;
        String email = request.getParameter("email");
        String confirm_email = request.getParameter("confirm_email");
        String password = request.getParameter("password1");
        String confirm_pass = request.getParameter("confirm_pass");
        String sec_que = request.getParameter("sec_que");
        String sec_ans = request.getParameter("sec_ans");
        
        String firstname = request.getParameter("firstname");
        String surname = request.getParameter("surname");
        String address = request.getParameter("address");
        String state = request.getParameter("state");
        String city = request.getParameter("city");
        String country = request.getParameter("country");
        String pincode = request.getParameter("pincode");
        String mobileno = request.getParameter("mobileno");
        String phone = request.getParameter("phone");
        String fax = request.getParameter("fax");
        String occupation = request.getParameter("occupation");

        String query1 = "insert into login values(?,?,?,?,?)";
        String query2 = "insert into fsee_details values(?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            if (email.equals(confirm_email) && password.equals(confirm_pass)) {

                dbconnector db = new dbconnector();
                db.connect();
                db.executepreparedstatement(query1);

                

                db.p.setString(1, email);
                db.p.setString(2, password);
                db.p.setString(3, usertype);
                db.p.setString(4, sec_que);
                db.p.setString(5, sec_ans);
                db.p.executeUpdate();

                db.executepreparedstatement(query2);
                db.p.setString(1, email);
                db.p.setString(2, firstname);
                db.p.setString(3, surname);
                db.p.setString(4, address);
                db.p.setString(5, city);
                db.p.setString(6, state);
                db.p.setString(7, country);
                db.p.setString(8, pincode);
                db.p.setString(9, mobileno);
                db.p.setString(10, phone);
                db.p.setString(11, fax);
                db.p.setString(12, occupation);
                db.p.executeUpdate();

                db.executepreparedstatement("insert into address_book values(?,?,?,?)");
                        db.p.setString(1, usertype);
                        db.p.setString(2, email);
                        db.p.setString(3, mobileno);
                        db.p.setString(4, firstname);
                        db.p.executeUpdate();

                String query3 = "insert into fsee_exp values(?,?,?,?,?,?,?)";

                String industry = request.getParameter("industry");
                String exp = request.getParameter("exp");
                String brand = request.getParameter("brand");
                String pref1 = request.getParameter("pref1");
                String pref2 = request.getParameter("pref2");
                String pref3 = request.getParameter("pref3");
                db.executepreparedstatement(query3);
                db.p.setString(1, email);
                db.p.setString(2, industry);
                db.p.setString(3, exp);
                db.p.setString(4, brand);
                db.p.setString(5, pref1);
                db.p.setString(6, pref2);
                db.p.setString(7, pref3);
                db.p.executeUpdate();

                String query4 = " insert into fsee_invest values(?,?,?,?,?,?)";
                String capacity = request.getParameter("capacity");
                String invest_time = request.getParameter("invest_time");
                String property_add = request.getParameter("property_add");
                String area = request.getParameter("area");
                String usage = request.getParameter("usage");

                 db.executepreparedstatement(query4);
                db.p.setString(1, email);
                db.p.setString(2, capacity);
                db.p.setString(3, invest_time);
                db.p.setString(4, property_add);
                db.p.setString(5, area);
                db.p.setString(6, usage);

                 db.p.executeUpdate();
                 


                session.setAttribute("email" , email);
                session.setAttribute("usertype", usertype);
                JOptionPane.showMessageDialog(null, "Registered successfully");
                response.sendRedirect("investorhome.jsp");

            } else {
                JOptionPane.showMessageDialog(null, "Registration failed");
                response.sendRedirect("index.jsp");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }


//        try {
//           dbconnector c = new dbconnector();
//           c.connect();
//           PreparedStatement p = c.c.prepareStatement("insert into login values(?,?)");
//           p.setString(1, request.getParameter("email"));
//           p.setString(2, request.getParameter("password1"));
//           p.executeUpdate();
//           JOptionPane.showMessageDialog(null, "1st step done");
//        }
//        catch(SQLException e) {
//            out.println(e.getMessage());
//        }
//        catch(ClassNotFoundException e) {
//            out.println(e.getMessage());
//        } finally {
//            out.close();
//        }
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException,
            IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException,
            IOException {
        processRequest(request, response);
    }
}
/**
 * Returns a short description of the servlet.
 * @return a String containing servlet description
 */
/*  @Override
public String getServletInfo() {
return "Short description";
}// </editor-fold>
 */
