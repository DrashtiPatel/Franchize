// JavaScript Document
$(document).ready(function () {
        //Set border color when text class getting focus or remove border color when lost focus from textbox.
        $('.text')
        .focus(function () { $('.text').removeClass('focused'); $(this).addClass('focused'); })
        .blur(function () { $(this).removeClass('focused'); });
 
        //Fire validation events
        $("#form").validate({
 
            //Setting validation type like, Required, Minimum or Maximum Length, Data Type etc.
            rules: {
                firstname: { required: true, minlength: 5, maxlength: 10 },
                lastname: { required: true, minlength: 5, maxlength: 10 },
                email: { required: true, email: true },
                mobile: { required: true, digits: true, minlength: 10, maxlength: 10 }
            },
 
            //All error labels are displayed inside an unordered list with the ID "validationSummary"
            //Additonal container for error messages. The elements given as the "errorContainer" are all shown and hidden when errors occur.
            errorContainer: "#validationSummary",
 
            //But the error labels themselve are added to the element(s) given as errorLabelContainer, here an unordered list.
            errorLabelContainer: "#validationSummary ul",
 
            //Therefore the error labels are also wrapped into li elements (wrapper option).
            wrapper: "li",
 
            //A custom message display handler. Gets the map of errors as the first argument and and array of errors as the second, 
            //called in the context of the validator object.
            showErrors: function (errorMap, errorList) {
                $('.errorList').hide();
                $('.inlineMessage').hide();
                $('#validationSummary').hide();
                var messages = "";
                $.each(errorList, function (index, value) {
                    var id = $(value.element).attr('id');
                    messages += "<span>" + (index + 1) + ". <a title='click to view field' href='javascript:setFocus(" + id + ");'>[" + $(value.element).attr('name') + "]</a> " + value.message + "</span>
";
                });
                messages = "
 
 
<div class='errorWrapper'>
 
 
<h1>Please correct following errors:</h1>
 
" + messages + "</div>
 
";
                switch ($('input[name=DisplayType]:checked', '#form').val()) {
                    case "Popup":
 
                        //Showing validation summary in Popup window
                        $('#dialog-validation').html(messages);
                        $('#dialog-validation').dialog('open');
                        break;
                    case "Summary List":
 
                        //Showing validation summary in list of the same page
                        $('#summary-validation').html(messages);
                        $('#summary-validation').show("fast");
                        break;
                    case "Inline":
 
                        //Showing validation in inline format
                        $.each(errorList, function (index, item) {
                            $(item.element).next('div').html("<span style='font-weight:bold'>[" + $(item.element).attr('name') + "]</span> " + item.message);
                            $(item.element).next('div').show("fast");
                        });
                        break;
                }
            },
 
            //If all validations are successfully validate then execute submitHandler function
            submitHandler: function () {
                $('#summary-validation').empty();
                $('#dialog-validation').empty();
                alert("All fields are valid!")
            }
        })
 
        //jQuery Modal Dialog boxes can also use to display list of validation erorrs.
        $("#dialog-validation").dialog({
            resizable: false,
            height: 190,
            width: 350,
            modal: true,
            autoOpen: false,
            title: "Validation Errors",
            buttons: {
                "Ok": function () {
                    $(this).dialog("close");
                    $('.focused').focus();
                }
            }
        });
    });
 
    //If validation errors are occured in any field, it will display field name with link, clicking on link it will set focus of perticular field.
    function setFocus(ele) {
        $(ele).focus();
    }